@extends('layouts.main')

@section('content')
    @include('layouts.list-events')
@endsection
