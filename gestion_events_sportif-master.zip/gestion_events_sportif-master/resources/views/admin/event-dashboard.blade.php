@extends('layouts.main')
@section('content')
    <h2>Admin: Events Dashboard</h2>
@endsection
