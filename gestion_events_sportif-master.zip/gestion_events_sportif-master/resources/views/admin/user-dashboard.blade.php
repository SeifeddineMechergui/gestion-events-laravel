@extends('layouts.main')
@section('content')
    <h2>Admin: Users Dashboard</h2>
@endsection
